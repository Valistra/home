#!/usr/bin/python3

from pyrob.api import *


@task
def task_7_5():
    A=1
    B=4
    C=1
    move_right(1)
    fill_cell()
    while (wall_is_on_the_right()==False):
        if (A<B):
           A=A+1 
        else:
            B=B+C
            C=C+1 
            fill_cell()
        move_right(1)
        if (3==A):
            move_left(n=2)
        
    pass


if __name__ == '__main__':
    run_tasks()
