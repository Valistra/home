#!/usr/bin/python3

from pyrob.api import *


@task
def task_8_27():
    a=0
    while (cell_is_filled()==False):
        move_up(n=1)
    else:
        fill_cell()
        move_left(n=1)
        if (cell_is_filled()!=False):
            fill_cell()
        else:
            move_right(n=2)
            fill_cell()


            
    pass


if __name__ == '__main__':
    run_tasks()
