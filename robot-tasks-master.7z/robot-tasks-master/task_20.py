#!/usr/bin/python3

from pyrob.api import *


@task(delay=0.05)
def task_4_3():
    move_up(n=1)
    for i in range(6):
        move_down(n=1)
        move_right(n=1)
        while (wall_is_on_the_right()==False):
            fill_cell()
            move_right(n=1)
        else:
            move_down(n=1)
            move_left(n=1)
            while (wall_is_on_the_left()==False):
                fill_cell()
                move_left(n=1)
    move_down(n=1)
    move_right(n=1)
            
    pass


if __name__ == '__main__':
    run_tasks()
