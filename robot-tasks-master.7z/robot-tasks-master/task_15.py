#!/usr/bin/python3

from pyrob.api import *


@task
def task_8_21():
    
    if (wall_is_beneath()==False and wall_is_on_the_right()==False) :
        move_down(9)
        move_right(9)
    elif (wall_is_beneath()==False and wall_is_on_the_left()==False):
        move_down(9)
        move_left(9)
    elif (wall_is_above()==False and wall_is_on_the_right()==False):
        move_up(9)
        move_right(9)
    elif (wall_is_above()==False and wall_is_on_the_left()==False):
        move_up(9)
        move_left(9)
    pass


if __name__ == '__main__':
    run_tasks()
