#!/usr/bin/python3

from pyrob.api import *


@task(delay=0.02)
def task_2_4():
    A=0
    for j in range (5):
        A=A+1
        B=0
        for i in range (10):
            B=B+1
            move_down(n=1)
            for i in range(2):
                fill_cell()
                move_right(n=1)
                fill_cell()
            move_down(n=1)
            move_left(n=1)
            for i in range(2):
                fill_cell()
                move_up(n=1)
                fill_cell()
            if (B!=10):
                move_right(n=3)
                
            
        move_left(n=37)
        if (A!=5):
           move_down(n=4) 
            
        
        
    pass


if __name__ == '__main__':
    run_tasks()
