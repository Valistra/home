#!/usr/bin/python3

from pyrob.api import *


@task
def task_5_10():
    while (wall_is_beneath()==False):
        if (wall_is_on_the_right()==False):
            while (wall_is_on_the_right()==False):
                fill_cell()
                move_right(n=1)
            fill_cell()
            move_down(n=1) 
        elif (wall_is_on_the_left()==False):
            while (wall_is_on_the_left()==False):
                fill_cell()
                move_left(n=1)
            fill_cell()
            move_down(n=1)



    while (wall_is_on_the_right()==False):
                fill_cell()
                move_right(n=1)
    else:
        fill_cell()
        while (wall_is_on_the_left()==False):
            fill_cell()
            move_left(n=1)
    fill_cell()
    pass


if __name__ == '__main__':
    run_tasks()
