#!/usr/bin/python3

from pyrob.api import *


@task(delay=0.2)
def task_9_3():
    A=0

    while (wall_is_on_the_right()==False):
        move_right(n=1)
        A=A+1
    else:
        C=A//2
        move_down(n=C)
        B=0


        
    while (C!=B):
        B=B+1
        fill_cell()
        move_left(n=1)
        
    di=B
    move_right(di)
    D=0
    B=B-1
    while (wall_is_above()==False):
         move_up(n=1)
         while (B!=0):
              D=D+1
              B=B-1
              fill_cell()
              move_left(D)
        else:
            
    else:
         move_down(C)
         move_left(n=1)
         move_right(di)
         while (wall_is_beneath()==False):
            B=B-1
            move_down(n=1)
            while (wall_is_on_the_right() and B!=0):
                D=D+1
                fill_cell()
                move_left(n=1)



    move_right(n=1)
    A=0
    B=0
    D=0
    move_left(C)
    while (C!=B):
        B=B+1
        fill_cell()
        move_up(n=1)
    else:
        move_down(di)
        while (wall_is_on_the_right()==False and B!=0):
               B=B-1
               move_right(n=1)
               while (B!=D and B!=0):
                   D=D+1
                   fill_cell()
                   move_up(n=1)
        else:
            move_left(C)
            move_up(n=1)
            move_down(di)
            B=di
            D=0
            while (wall_is_on_the_left()==False and B!=0):
                B=B-1
                move_left(n=1)
                while (B!=D and B!=0):
                    D=D+1
                    fill_cell()
                    move_up(n=1)

    move_down(1)
    A=0
    B=0
    D=0
    move_up(C)
    while (C!=B):
        B=B+1
        fill_cell()
        move_right(n=1)
    else:
        move_left(di)
        while (wall_is_beneath()==False and B!=0):
               B=B-1
               move_down(n=1)
               while (B!=D and B!=0):
                   D=D+1
                   fill_cell()
                   move_right(n=1)
        else:
            move_up(C)
            move_right(n=1)
            move_left(di)
            B=di
            D=0
            while (wall_is_above()==False and B!=0):
                B=B-1
                move_up(n=1)
                while (B!=D and B!=0):
                    D=D+1
                    fill_cell()
                    move_right(n=1)

    move_left(n=1)
    A=0
    B=0
    D=0
    move_right(C)
    while (C!=B):
        B=B+1
        fill_cell()
        move_down(n=1)
    else:
        move_up(di)
        while (wall_is_on_the_left()==False and B!=0):
               B=B-1
               move_left(n=1)
               while (B!=D and B!=0):
                   D=D+1
                   fill_cell()
                   move_left(n=1)
        else:
            move_right(C)
            move_down(n=2)
            move_up(di)
            B=di
            D=0
            while (wall_is_on_the_right()==False and B!=0):
                B=B-1
                move_right(n=1)
                while (B!=D and B!=0):
                    D=D+1
                    fill_cell()
                    move_right(n=1)
    while (wall_is_beneath()==False):
        move_down(n=1)
    else:
        while (wall_is_on_the_left()==False):
            move_left(n=1)
            
            
        


                       
    
        
        
        
           
            
        
           
                
       
        
    

    
    
            
            
               
               
    
        
            
                
                    
            
                
        
    pass
def Cikl_1():
    
    pass

if __name__ == '__main__':
    run_tasks()
