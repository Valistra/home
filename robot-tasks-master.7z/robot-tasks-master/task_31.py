#!/usr/bin/python3

from pyrob.api import *


@task(delay=0.02)
def task_8_30():
    A=0
    while (A<3):
        if (wall_is_beneath()==False):
            while (wall_is_beneath()==False):
                move_down(n=1)
                A=0


                
        elif (A>2):
            while (wall_is_on_the_left()==False and wall_is_beneath()!=False):
                move_left(n=1)

                
        elif (wall_is_on_the_left()==False and wall_is_beneath()!=False):
            A=A+1
            while (wall_is_on_the_left()==False and wall_is_beneath()!=False):
                move_left(n=1)
            else:
                while (wall_is_beneath()==False):
                    move_down(n=1)
                    A=0

                    
        elif (wall_is_on_the_right()==False and wall_is_beneath()!=False):
            A=A+1
            while (wall_is_on_the_right()==False and wall_is_beneath()!=False):
                move_right(n=1)
            else:
                while (wall_is_beneath()==False):
                    move_down(n=1)
                    A=0
     
    pass


if __name__ == '__main__':
    run_tasks()
