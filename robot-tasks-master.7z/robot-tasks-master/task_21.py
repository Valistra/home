#!/usr/bin/python3

from pyrob.api import *


@task(delay=0.05)
def task_4_11():
    A=1
    for i in range(13):
        move_right(n=1)
        move_down(A)
        while (wall_is_beneath()==False):
            fill_cell()
            move_down(n=1)
    
        else:
            while (wall_is_above()==False):
                move_up(n=1)
            A=A+1
    move_left(n=12)
    move_down(n=14)
           
        
    pass


if __name__ == '__main__':
    run_tasks()
