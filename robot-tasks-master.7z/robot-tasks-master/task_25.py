#!/usr/bin/python3

from pyrob.api import *


@task
def task_2_2():
    for i in range (4):
        move_down(n=2)
        for i in range(2):
            fill_cell()
            move_right(n=1)
            fill_cell()
        move_down(n=2)
        move_left(n=1)
        for i in range(3):
            move_up(n=1)
            fill_cell()
        move_up(n=1)
        move_right(n=3)
    move_down(n=2)
    for i in range(2):
        fill_cell()
        move_right(n=1)
        fill_cell()
    move_down(n=2)
    move_left(n=1)
    for i in range(3):
        move_up(n=1)
        fill_cell()
    move_left(n=1)
        
    pass


if __name__ == '__main__':
    run_tasks()
