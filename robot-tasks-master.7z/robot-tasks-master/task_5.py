#!/usr/bin/python3

from pyrob.api import *


@task
def task_5_2():
    while (wall_is_beneath()!=False):
        move_right(n=1)
    pass


if __name__ == '__main__':
    run_tasks()
