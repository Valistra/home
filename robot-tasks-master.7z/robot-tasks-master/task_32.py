#!/usr/bin/python3

from pyrob.api import *


@task(delay=0.01)
def task_8_18():
    A=0
    AX=0
    while (wall_is_on_the_right()==False):
        if (wall_is_above()!=False and wall_is_beneath()!=False):
            fill_cell()
            move_right(n=1)
        else:
            if (wall_is_above()==False and wall_is_beneath()!=False):
                move_up(n=1)
                if (cell_is_filled()==True):
                    A=A+1
                fill_cell()
                while (wall_is_on_the_left()!=False and wall_is_above()==False):
                    move_up(n=1)
                    if (cell_is_filled()==True):
                        A=A+1
                    fill_cell()
                else:
                    while (wall_is_beneath()==False):
                        move_down(n=1)
            move_right(n=1)
    print(A)
    mov(AX,A)
        
   
    pass



if __name__ == '__main__':
    run_tasks()
